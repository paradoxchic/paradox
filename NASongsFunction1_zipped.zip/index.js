// JavaScript source code
/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample modified for Alexa Dev Group Amazon Alexa Skills
 * nodejs skill development kit.
  * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';

const Alexa = require('alexa-sdk');

const APP_ID = "amzn1.ask.skill.659552d3-ab03-4655-9070-91e833f96ab6";

var SONGS =
["Australia","USA","Brazil","Canada","China","France","Germany","Greece","Israel","Italy","Mexico","UK","Costa Rica","Camaroon","Cuba","Egypt","Japan","Romania","South Africa","Spain","India","Philippines"];
//	["Australia","Brazil","Canada","China","France","Germany","Greece","Israel","Italy","Mexico","United Kingdom","USA"];
var HINTS =
	[   "A desert area known as the outback covers much of the land.",
	    "This country is known as the Land of the Free and Home of the Brave.",
	    "This country was named after a tree and holds 60% of the Amazon Rain Forest.",
		"The Blackberry Smartphone was developed in Ontario, at Research In Motion\'s' Waterloo offices.",
		"The Great Wall is the largest man made structure in the world.",
		"The worlds most visited country and home to the Louvre Museum.",
		"This country hosts Oktoberfest, the world\'s' biggest folk festival.",
		"Know for mythology, and the origintor of the Olympic Games.",
		"Known as the Holy Land, this country has the third highest rate of entrepreneurship.",
		"This country is said to have more masterpieces per square mile than any other country in the world.",
		"This South of the Border country serves tacos, burritos and enchiladas.",
		"James Bond\'s' code  DOUBLE O SEVEN  was inspired by Ian Fleming\'s'  bus route from Canterbury to London.",
		"There are 800 miles of Atlantic and Pacific coastline and this country is ranked 5th for Medical Tourism.",
"It is the most urban and ethnically diverse nation in western Africa, and produces smooth cigar wrappers.",
"This country is the largest island in the Caribbean, and from the air resembles a crocodile.",
"Home to the Great Pyramid of Giza, one of the Seven Wonders of the Ancient World.",
"Home to Mount Fuji, this country is a world leader in robotics including human-like robots such as ASIMO.",
"This country was a source of inspiration for the novel Dracula by Bram Stoker.",
"This country has 3 capital cities and is home to a wide variety of animals like giraffes, hippopotamus, leopards and lions.",
"This country is famous for The Running of the Bulls in Pamplona.",
"Mahatma Gandhi is famous for the important part he played in gaining this country\'s' independence.",
"The first patented producer of the karaoke is from this country which leads the world in coconuts production."	];
		//		"Mahatma Gandhi is famous for the important part he played in gaining this country's independence.",

var speech;
var slotValue;

const languageStrings = {
	'en': {
		translation: {

			SKILL_NAME: 'National Anthems',
			GET_FACT_MESSAGE: "Would you like the song for this country? ",
			HELP_MESSAGE: 'You can say give me a hint. What would you like to do next?',
			HELP_REPROMPT: 'Do you still want to play National Anthems?',
			STOP_MESSAGE: 'Thanks for playing and come back soon. We add new anthems often.', 
			CANCEL_MESSAGE: 'Thanks for playing and come back soon. We add new anthems often.',
			SHOULD_END_SESSION: 'false',

		},
	},
	'en-US': {
		translation: {

			SKILL_NAME: 'National Anthems',
			GET_FACT_MESSAGE: "Would you like the song for this country? ",
			HELP_MESSAGE: 'You can say give me a hint. What would you like to do next?',
			HELP_REPROMPT: 'Do you still want to play National Anthems?',
			STOP_MESSAGE: 'Thanks for playing and come back soon. We add new anthems often.', 
			CANCEL_MESSAGE: 'Thanks for playing and come back soon. We add new anthems often.',
			SHOULD_END_SESSION: 'false',
		},
	},
	'en-GB': {
		translation: {

			SKILL_NAME: 'National Anthems',
			GET_FACT_MESSAGE: "Would you like the song for this country? ",
			HELP_MESSAGE: 'You can say give me a hint. What would you like to do next?',
			HELP_REPROMPT: 'Do you still want to play National Anthems?',
			STOP_MESSAGE: 'Thanks for playing and come back soon. We add new anthems often.', 
			CANCEL_MESSAGE: 'Thanks for playing and come back soon. We add new anthems often.',
			SHOULD_END_SESSION: 'false',
		},
	},
};
var welcomeMessage = 
                    'Welcome to National Anthems! An anthem will play and you name the country. If you need a hint after the anthem plays, you can say Give Me a Hint. Say Start Game or Play Anthem.';
var speechOutput;
var anthemURL;
var songIndex;
var randomURL;
var hintMessage;
var songCount;
var lastSongIndex;
///var countryTracker =  SONGS.slice(); 

var states = {
	GUESSMODE: '_GUESSMODE', // User is trying to guess the Anthem.
	STARTMODE: '_STARTMODE',  // Prompt the user to start or restart the game.
//	CONTINUEMODE:  '_CONTINUEMODE',   // Prompt to say Next Anthem.
//	HINTMODE:      '_HINTMODE',
//	ANSWERMODE:    '_ANSWERMODE'
};

var newSessionHandlers = {

	// This will short-cut any incoming intent or launch requests and route them to this handler.

	'NewSession': function () {

		this.handler.state = states.STARTMODE;

		this.emit(':ask', welcomeMessage);

	}

};
// On launch, we tell the user what they can do (Play Athems :-))

const handlers =
	{
		'LaunchRequest': function () {
//		    this.handler.state = states.STARTMODE;
			this.emit(':ask', welcomeMessage, welcomeMessage);
		},

		// HELP the user guess the contry
		'GetHintIntent': function () {
//		    if (this.handler.state == states.HINTMODE)
//		    {
//		        this.emit('AnswerIntent');
//		    }
//		    else
//		    this.handler.state = states.HINTMODE;
			var hintMessage = HINTS[songIndex];
			speechOutput = " ";
			speechOutput = hintMessage;
			var string1 = '<break time="1s" />';
			var string2 = 'Name the country.';
			speechOutput = speechOutput + string1 + string2;
			this.emit(':ask', speechOutput);
		},

		// This starts the playing of a random anthem
		'PlayAnthemIntent': function () {
//			this.handler.state = states.GUESSMODE;
			this.emit('PlayWithAsk');
			//this.emit('PlaySong');
			var SongCount = SongCount += 1;
			console.log(SongCount);
			console.log('about to execute PlayWithAsk function');
		},

		//Play the song using ask feature
		'PlayWithAsk': function () {
			var string1, string2, string3, string4;
			
		const songArr = this.t('SONGS');
		
//		for (var a=[],i=0;i<12;++i) a[i]=i;

// http://stackoverflow.com/questions/962802#962890
//function shuffle(songArr) {
//  var tmp, current, top = songArr.length;
//  if(top) while(--top) {
//    current = Math.floor(Math.random() * (top + 1));
//    tmp = songArr[current];
//    songArr[current] = songArr[top];
//    songArr[top] = tmp;
//  }
//  return songArr;
//}

//a = shuffle(a);
         
 		songIndex = Math.floor(Math.random() * 20);
//		  songIndex = 11;
//			lastSongIndex = songIndex;

			randomURL = SONGS[songIndex];  //SONGS[Math.floor(Math.random() * songArr.length)];
		var	randomURL_clip = randomURL.replace(/\s+/g,"");
			
 //  if (countryTracker.length >= 0) {
 //    countryTracker.pop(songIndex);}
 //    else { countryTracker.clear(); countryTracker= SONGS.slice(); }
   

     
     
     var songurl = "https://s3.amazonaws.com/natanthems.adg.aws.com/" + randomURL_clip + "_Clip.mp3";

			// var songurl = "https://s3.amazonaws.com/natanthems.adg.aws.com/USA11.mp3";

			var quotes = '"';
			var audiostring = quotes + songurl + quotes;
			anthemURL = "<audio src=" + audiostring + " />";
			console.log(anthemURL);

			string1 = ('Playing. ');
			string2 = anthemURL;
			string3 = ('<break time="1s" /> Name the country.');
			speech = string1 + string2 + string3;
			speechOutput = {
				type: "ssml",
				ssml: speech
			};
			this.emit(':ask', speechOutput.ssml, speechOutput.ssml);
		},

		// Validate the answer
		"AnswerIntent": function () {
//	var answerSlotValid = isAnswerSlotValid(this.event.request.intent);
//	this.handler.state = states.ANSWERMODE;

			var speechOutput = "";
			var speechOutputAnalysis = "";
			var intent = 'AnswerIntent';
			var answer = 'answer';
			//				var currentScore = parseInt(this.attributes.score);
			//				var currentQuestionIndex = songIndex;
		
			var correctAnswerText = " ";
			    correctAnswerText = randomURL;

			 
			
            if  (this.event.request.intent.slots.answer.value  == "United Kingdom")  
                {this.event.request.intent.slots.answer.value = "UK";} 
             if (this.event.request.intent.slots.answer.value  == "Britain") 
                {this.event.request.intent.slots.answer.value = "UK";} 
             if (this.event.request.intent.slots.answer.value  == "Great Britain")
                {this.event.request.intent.slots.answer.value = "UK";} 
                 
                                          
             
            if  (this.event.request.intent.slots.answer.value ==  "America") 
                {this.event.request.intent.slots.answer.value   = "USA";}
             if (this.event.request.intent.slots.answer.value  == "United States")
                {this.event.request.intent.slots.answer.value   = "USA";}
             if (this.event.request.intent.slots.answer.value  == "United States of America")
                {this.event.request.intent.slots.answer.value   = "USA";}
            
               slotValue = this.event.request.intent.slots.answer.value;
console.log(slotValue);

//			var hint = 'hint';
//			hintMessage = this.event.request.intent.slots.hint.value;

			//               var songIndex = SONGS.indexOf(slotValue , 0);
//			console.log(hintMessage);

			//	var translatedQuestions = this.t("QUESTIONS");
			var repromptOutput = "say next anthem to continue.";

			if (slotValue == randomURL) speechOutput = "Correct";//this.t("ANSWER_CORRECT_MESSAGE");
			if (slotValue !== randomURL) speechOutput = "Incorrect, the answer is " + randomURL; //this.t("ANSWER_WRONG_MESSAGE");
			if (randomURL === null) speechOutput = "You can say give me a Hint, or";//this.t("CORRECT_ANSWER_MESSAGE");
			speechOutput = speechOutput + ', say next anthem to continue.';
			console.log(speechOutput + randomURL);

			var response =
				{
					"version": "1.0",
					"sessionAttributes": {},
					"response": {
						"outputSpeech": {
							"type": "PlainText",
							"text": speechOutput
						}
					},
					"reprompt": {
						"outputSpeech": {
							"type": "PlainText",
							"text": repromptOutput
						}
					},
					"shouldEndSession": false
				};
			this.emit(':ask', speechOutput, repromptOutput);

			//Response to IntentRequest 


			//			} catch (e) {
			//				context.fail("Exception: " + e);
			//			}
		},


		// Obsolete for the moment
		//Play the song
		'PlaySong': function (audioURL, offsetInMilliseconds) {
			console.log('About to play audion ');
			const songArr = this.t('SONGS');
			var songIndex = Math.floor(Math.random() * songArr.length);
			randomURL = SONGS[songIndex];           //SONGS[Math.floor(Math.random() * songArr.length)];
			var anthemURL = "https://s3.amazonaws.com/natanthems/" + randomURL + ".mp3";
			var response =
				{
					"version": "1.0",
					"sessionAttributes": {},
					"response":
					{
						"outputSpeech": {
							"type": "PlainText",
							"text": "Playing Anthem for " + randomURL + " now."

						},

						"card": {
							"type": "Simple",
							"title": "Play Audio",
							"content": "Playing number " + songIndex + " Anthem at " + randomURL + " location."
						},

						"directives": [
							{
								"type": "AudioPlayer.Play",
								"playBehavior": "REPLACE_ALL",
								"audioItem": {
									"stream": {
										"token": "string",
										"url": anthemURL,
										"offsetInMilliseconds": 0
									}
								}
							},
							{
								"type": "AudioPlayer.Stop"
							}
						]
					},
					"shouldEndSession": false
				}; // ends the response inside PlaySong 
			this.context.succeed(response);
			//  this.emit(':ask','Can you name the country?');
			//    this.emit('AnswerIntent');
		}, //ends PlaySong function
		// Playback Started required?
		//end Obsolute code

		// Stops the playback of Audio
		'AMAZON.StopIntent': function () {
			var response = {
				"version": "1.0",
				"sessionAttributes": {},
				"response":
				{
					"outputSpeech": {
						"type": "PlainText",
						"text": "OK, what next?"

					},
					directives: [
						{
							type: "AudioPlayer.Stop"

						}
					]
				},

				"shouldEndSession": true

			};

			this.emit(':tell',  this.t('STOP_MESSAGE'));
		},



		// user DOESN'T KNOW the answer
		"DontKnowIntent": function () {
//		    if (this.states.mode == states.HINTMODE)
//		    {this.emit('AnswerIntent');}
//		    else
//		    this.states.mode = states.HINTMODE;
			var intent = 'DontKnowIntent';
//			var answer = 'answer';

//			var correctAnswerText = randomURL;

//			var slotValue = this.event.request.intent.slots.answer.value;
			var string1 = "The country is ";
			var string3 = ", Say next anthem to continue.";
			var repromptOutput = "Say next anthem to continue.";
//			var string2 = "<break time='1s' />";
			speechOutput = string1 + randomURL  + string3;
			this.emit(':ask', speechOutput,repromptOutput);
		},

		// UNHANDELED	 	
		'Unhandled': function () {
			this.emit(':tell',
				'Sorry, but I did not understand. What would you like to do?');
		},
		'AMAZON.HelpIntent': function () {
			const speechOutput = this.t('HELP_MESSAGE');
			const reprompt = this.t('HELP_MESSAGE');
			this.emit(':ask', speechOutput, reprompt);
		},
		'AMAZON.CancelIntent': function () {
			this.emit(':tell', this.t('STOP_MESSAGE'));
		},
		//    'AMAZON.StopIntent': function () {
		//       this.emit(':tell', this.t('STOP_MESSAGE'));
		//   },


		'SessionEndedRequest': function () {
			console.log('session ended!');
		}
	};



exports.handler = function (event, context) {
	const alexa = Alexa.handler(event, context);
	alexa.appID = APP_ID;
	// To enable string internationalization (i18n) features, set a resources object.
	alexa.resources = languageStrings;
	alexa.registerHandlers(handlers);
	alexa.execute();
};// JavaScript source code



